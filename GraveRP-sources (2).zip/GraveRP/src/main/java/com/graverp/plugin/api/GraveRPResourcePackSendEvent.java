package com.graverp.plugin.api;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

/**
 * Вызывается GraveRP непосредственно ПЕРЕД отправкой ресурспака игроку
 * (перед вызовом {@code Player#setResourcePack}).
 *
 * Сторонние плагины (например GraveRPAddon) могут подписаться на это
 * событие, чтобы показать собственную подсказку/текст точно в момент
 * появления системного окна подтверждения ресурспака, а также при
 * необходимости отменить отправку ресурспака.
 *
 * Это публичный API GraveRP - используйте его в других плагинах,
 * добавив GraveRP.jar как provided-зависимость.
 */
public class GraveRPResourcePackSendEvent extends PlayerEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final String url;
    private boolean cancelled;

    public GraveRPResourcePackSendEvent(Player who, String url) {
        super(who);
        this.url = url;
    }

    /**
     * @return итоговая (уже преобразованная через ResourcePackLinkResolver)
     *         ссылка на ресурспак, которая будет отправлена игроку
     */
    public String getUrl() {
        return url;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    /**
     * Если отменить это событие - GraveRP не будет отправлять ресурспак
     * игроку в этот раз (полезно, если сторонний плагин хочет сам
     * управлять отправкой, например с задержкой).
     */
    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
