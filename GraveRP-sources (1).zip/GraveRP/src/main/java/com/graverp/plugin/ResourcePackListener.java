package com.graverp.plugin;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class ResourcePackListener implements Listener {

    private final GraveRP plugin;

    public ResourcePackListener(GraveRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Пока статус не подтверждён - считаем, что кастомных символов нет
        plugin.setPackStatus(player.getUniqueId(), PackStatus.UNKNOWN);

        if (!plugin.getConfig().getBoolean("send_on_join", true)) {
            return;
        }

        String url = plugin.getConfig().getString("resource_pack_url", "");
        if (url == null || url.trim().isEmpty()) {
            return;
        }

        long delay = plugin.getConfig().getLong("send_delay", 20L);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    return;
                }
                sendResourcePack(player, url);
            }
        }.runTaskLater(plugin, Math.max(0L, delay));
    }

    private void sendResourcePack(Player player, String url) {
        String hashHex = plugin.getConfig().getString("resource_pack_hash", "");

        boolean autoConvert = plugin.getConfig().getBoolean("auto_convert_links", true);
        if (autoConvert) {
            String resolved = ResourcePackLinkResolver.resolve(url);
            if (resolved != null && !resolved.equals(url)) {
                plugin.getLogger().info("Ссылка на ресурспак преобразована в прямую: " + resolved);
            }
            url = resolved;
        }

        try {
            if (hashHex != null && !hashHex.trim().isEmpty()) {
                byte[] hash = hexStringToByteArray(hashHex.trim());
                player.setResourcePack(url, hash);
            } else {
                player.setResourcePack(url);
            }
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("Некорректная ссылка или хэш ресурспака: " + ex.getMessage());
        }
    }

    @EventHandler
    public void onResourcePackStatus(PlayerResourcePackStatusEvent event) {
        Player player = event.getPlayer();
        PlayerResourcePackStatusEvent.Status status = event.getStatus();

        switch (status) {
            case SUCCESSFULLY_LOADED:
                plugin.setPackStatus(player.getUniqueId(), PackStatus.ACCEPTED);
                sendMessage(player, "success_message");
                break;
            case DECLINED:
                plugin.setPackStatus(player.getUniqueId(), PackStatus.DECLINED);
                sendMessage(player, "decline_message");
                break;
            case FAILED_DOWNLOAD:
                plugin.setPackStatus(player.getUniqueId(), PackStatus.FAILED);
                sendMessage(player, "failed_message");
                break;
            case ACCEPTED:
                // Игрок согласился на загрузку, но она ещё не завершена.
                // Символы ресурспака появятся после SUCCESSFULLY_LOADED.
                break;
            default:
                break;
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.clearPackStatus(event.getPlayer().getUniqueId());
    }

    private void sendMessage(Player player, String path) {
        String message = plugin.getConfig().getString(path, "");
        if (message == null || message.trim().isEmpty()) {
            return;
        }
        player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
    }

    private static byte[] hexStringToByteArray(String hex) {
        String clean = hex.replace(" ", "");
        int len = clean.length();
        if (len % 2 != 0) {
            throw new IllegalArgumentException("Длина хэша должна быть чётной");
        }
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(clean.charAt(i), 16) << 4)
                    + Character.digit(clean.charAt(i + 1), 16));
        }
        return data;
    }
}
