package com.graverp.plugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Преобразует "человеческие" ссылки на файлы (Dropbox, Google Drive, GitHub)
 * в прямые ссылки для скачивания, которые понимает клиент Minecraft.
 *
 * Если ссылка уже является прямой (или сервис не распознан) - возвращается
 * без изменений.
 */
public final class ResourcePackLinkResolver {

    private static final Pattern GOOGLE_DRIVE_FILE_ID =
            Pattern.compile("drive\\.google\\.com/file/d/([a-zA-Z0-9_-]+)");

    private static final Pattern GOOGLE_DRIVE_OPEN_ID =
            Pattern.compile("drive\\.google\\.com/open\\?id=([a-zA-Z0-9_-]+)");

    private static final Pattern GOOGLE_DRIVE_UC_ID =
            Pattern.compile("drive\\.google\\.com/uc\\?(?:export=download&)?id=([a-zA-Z0-9_-]+)");

    private static final Pattern GITHUB_BLOB =
            Pattern.compile("github\\.com/([^/]+)/([^/]+)/blob/([^?#]+)");

    private static final Pattern GITHUB_RAW_ALREADY =
            Pattern.compile("raw\\.githubusercontent\\.com");

    private static final Pattern GITHUB_RELEASES_ALREADY =
            Pattern.compile("github\\.com/[^/]+/[^/]+/releases/download/");

    private ResourcePackLinkResolver() {
    }

    /**
     * @param rawUrl ссылка, указанная в config.yml
     * @return прямая ссылка на файл, готовая для {@code Player#setResourcePack}
     */
    public static String resolve(String rawUrl) {
        if (rawUrl == null) {
            return null;
        }

        String url = rawUrl.trim();
        if (url.isEmpty()) {
            return url;
        }

        String resolved = tryDropbox(url);
        if (resolved != null) {
            return resolved;
        }

        resolved = tryGoogleDrive(url);
        if (resolved != null) {
            return resolved;
        }

        resolved = tryGitHub(url);
        if (resolved != null) {
            return resolved;
        }

        // Неизвестный/уже прямой хост - отдаём как есть
        return url;
    }

    // ---------------------------------------------------------------
    // Dropbox
    // ---------------------------------------------------------------
    private static String tryDropbox(String url) {
        if (!url.contains("dropbox.com")) {
            return null;
        }

        // dl.dropboxusercontent.com уже является прямой ссылкой
        if (url.contains("dl.dropboxusercontent.com")) {
            return url;
        }

        // www.dropbox.com/scl/... или www.dropbox.com/s/...
        String converted = url.replace("www.dropbox.com", "dl.dropboxusercontent.com")
                .replace("dropbox.com", "dl.dropboxusercontent.com");

        if (converted.contains("dl=0")) {
            converted = converted.replace("dl=0", "dl=1");
        } else if (!converted.contains("dl=1")) {
            converted += (converted.contains("?") ? "&" : "?") + "dl=1";
        }

        return converted;
    }

    // ---------------------------------------------------------------
    // Google Drive
    // ---------------------------------------------------------------
    private static String tryGoogleDrive(String url) {
        if (!url.contains("drive.google.com") && !url.contains("docs.google.com")) {
            return null;
        }

        String fileId = extractGoogleDriveId(url);
        if (fileId == null) {
            return null;
        }

        return "https://drive.google.com/uc?export=download&id=" + fileId;
    }

    private static String extractGoogleDriveId(String url) {
        Matcher fileMatcher = GOOGLE_DRIVE_FILE_ID.matcher(url);
        if (fileMatcher.find()) {
            return fileMatcher.group(1);
        }

        Matcher openMatcher = GOOGLE_DRIVE_OPEN_ID.matcher(url);
        if (openMatcher.find()) {
            return openMatcher.group(1);
        }

        Matcher ucMatcher = GOOGLE_DRIVE_UC_ID.matcher(url);
        if (ucMatcher.find()) {
            return ucMatcher.group(1);
        }

        return null;
    }

    // ---------------------------------------------------------------
    // GitHub
    // ---------------------------------------------------------------
    private static String tryGitHub(String url) {
        if (!url.contains("github.com") && !url.contains("githubusercontent.com")) {
            return null;
        }

        // Уже raw-ссылка или ссылка на release-ассет - трогать не нужно
        if (GITHUB_RAW_ALREADY.matcher(url).find() || GITHUB_RELEASES_ALREADY.matcher(url).find()) {
            return url;
        }

        // https://github.com/user/repo/blob/branch/path/file.zip
        // -> https://raw.githubusercontent.com/user/repo/branch/path/file.zip
        Matcher blobMatcher = GITHUB_BLOB.matcher(url);
        if (blobMatcher.find()) {
            String user = blobMatcher.group(1);
            String repo = blobMatcher.group(2);
            String pathAfterBlob = blobMatcher.group(3);
            return "https://raw.githubusercontent.com/" + user + "/" + repo + "/" + pathAfterBlob;
        }

        return null;
    }
}
