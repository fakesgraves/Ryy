package com.graverp.plugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GraveRPCommand implements CommandExecutor, TabCompleter {

    private final GraveRP plugin;

    public GraveRPCommand(GraveRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("graverp.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав на использование этой команды.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.GOLD + "GraveRP " + ChatColor.GRAY + "v" + plugin.getDescription().getVersion());
            sender.sendMessage(ChatColor.YELLOW + "/graverp reload " + ChatColor.GRAY + "- перезагрузить config.yml");
            sender.sendMessage(ChatColor.YELLOW + "/graverp status [ник] " + ChatColor.GRAY + "- проверить статус ресурспака игрока");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reloadPluginConfig();
            sender.sendMessage(ChatColor.GREEN + "Конфигурация GraveRP успешно перезагружена.");
            return true;
        }

        if (args[0].equalsIgnoreCase("status")) {
            Player target;
            if (args.length >= 2) {
                target = plugin.getServer().getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                    return true;
                }
            } else if (sender instanceof Player) {
                target = (Player) sender;
            } else {
                sender.sendMessage(ChatColor.RED + "Укажите ник игрока: /graverp status <ник>");
                return true;
            }

            PackStatus status = plugin.getPackStatus(target);
            sender.sendMessage(ChatColor.GOLD + target.getName() + ChatColor.GRAY + " -> "
                    + ChatColor.YELLOW + status.name());
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Неизвестная подкоманда. Используйте /graverp");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>();
            for (String sub : new String[]{"reload", "status"}) {
                if (sub.startsWith(args[0].toLowerCase())) {
                    options.add(sub);
                }
            }
            return options;
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("status")) {
            List<String> names = new ArrayList<>();
            plugin.getServer().getOnlinePlayers().forEach(p -> {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    names.add(p.getName());
                }
            });
            return names;
        }

        return Collections.emptyList();
    }
}
