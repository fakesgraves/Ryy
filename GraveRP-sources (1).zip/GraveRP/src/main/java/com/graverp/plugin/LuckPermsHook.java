package com.graverp.plugin;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.cacheddata.CachedMetaData;
import net.luckperms.api.model.user.User;
import org.bukkit.entity.Player;

/**
 * Обёртка над LuckPerms API для получения префикса игрока (например,
 * префикса доната/ранга), чтобы показывать его через плейсхолдер GraveRP.
 */
public class LuckPermsHook {

    private final LuckPerms api;

    /**
     * @throws IllegalStateException если LuckPerms не запущен/не захукан на сервере
     */
    public LuckPermsHook() {
        this.api = LuckPermsProvider.get();
    }

    /**
     * @return префикс игрока (может содержать цветовые коды &) или null,
     *         если у игрока нет префикса / данные ещё не загружены
     */
    public String getPrefix(Player player) {
        User user = api.getUserManager().getUser(player.getUniqueId());
        if (user == null) {
            return null;
        }

        CachedMetaData metaData = user.getCachedData().getMetaData();
        return metaData.getPrefix();
    }
}
