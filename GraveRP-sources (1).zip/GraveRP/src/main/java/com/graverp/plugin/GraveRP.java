package com.graverp.plugin;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class GraveRP extends JavaPlugin {

    private static GraveRP instance;

    /** Статус ресурспака каждого игрока по UUID. */
    private final Map<UUID, PackStatus> packStatusMap = new ConcurrentHashMap<>();

    private GraveRPExpansion expansion;
    private LuckPermsHook luckPermsHook;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        // Регистрируем слушателя событий
        getServer().getPluginManager().registerEvents(new ResourcePackListener(this), this);

        // Регистрируем команду /graverp
        GraveRPCommand commandExecutor = new GraveRPCommand(this);
        getCommand("graverp").setExecutor(commandExecutor);
        getCommand("graverp").setTabCompleter(commandExecutor);

        // Подключаемся к LuckPerms, если он установлен (нужен для плейсхолдера доната)
        setupLuckPerms();

        // Регистрируем плейсхолдеры PlaceholderAPI
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            expansion = new GraveRPExpansion(this);
            expansion.register();
            getLogger().info("Плейсхолдеры PlaceholderAPI успешно зарегистрированы (%graverp_<ключ>%).");
        } else {
            getLogger().warning("PlaceholderAPI не найден! Плейсхолдеры работать не будут.");
        }

        getLogger().info("GraveRP включен.");
    }

    private void setupLuckPerms() {
        if (getServer().getPluginManager().getPlugin("LuckPerms") == null) {
            getLogger().info("LuckPerms не найден. Плейсхолдер доната (%graverp_donate%) будет возвращать значение по умолчанию.");
            luckPermsHook = null;
            return;
        }

        try {
            luckPermsHook = new LuckPermsHook();
            getLogger().info("Успешно подключились к LuckPerms.");
        } catch (IllegalStateException ex) {
            getLogger().warning("Не удалось подключиться к LuckPerms: " + ex.getMessage());
            luckPermsHook = null;
        }
    }

    @Override
    public void onDisable() {
        if (expansion != null) {
            expansion.unregister();
        }
        packStatusMap.clear();
        getLogger().info("GraveRP выключен.");
    }

    /**
     * Перезагружает config.yml.
     */
    public void reloadPluginConfig() {
        reloadConfig();
    }

    public PackStatus getPackStatus(UUID uuid) {
        return packStatusMap.getOrDefault(uuid, PackStatus.UNKNOWN);
    }

    public PackStatus getPackStatus(Player player) {
        return getPackStatus(player.getUniqueId());
    }

    public void setPackStatus(UUID uuid, PackStatus status) {
        packStatusMap.put(uuid, status);
    }

    public void clearPackStatus(UUID uuid) {
        packStatusMap.remove(uuid);
    }

    /**
     * @return хук LuckPerms или null, если LuckPerms не установлен/не подключился
     */
    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }

    public static GraveRP getInstance() {
        return instance;
    }
}
