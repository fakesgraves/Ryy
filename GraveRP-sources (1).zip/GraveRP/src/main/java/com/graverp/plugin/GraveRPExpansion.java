package com.graverp.plugin;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class GraveRPExpansion extends PlaceholderExpansion {

    private final GraveRP plugin;

    public GraveRPExpansion(GraveRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        // Итоговый плейсхолдер: %graverp_<ключ>%
        return "graverp";
    }

    @Override
    public String getAuthor() {
        return "GraveRP";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    /**
     * persist() = true - плейсхолдер не будет выгружен при /papi reload
     */
    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        if (player == null) {
            return "";
        }

        // %graverp_donate% - отдельный плейсхолдер для отображения доната.
        // Если у игрока есть префикс из LuckPerms (донат/ранг) - показываем его
        // вместо обычного символа ресурспака.
        if (params.equalsIgnoreCase("donate")) {
            return onDonatePlaceholderRequest(player);
        }

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("placeholders." + params);
        if (section == null) {
            return "";
        }

        boolean hasPack = plugin.getPackStatus(player).hasPack();

        String value = hasPack
                ? section.getString("has_pack", "")
                : section.getString("no_pack", "");

        if (value == null) {
            value = "";
        }

        return ChatColor.translateAlternateColorCodes('&', value);
    }

    private String onDonatePlaceholderRequest(Player player) {
        if (!plugin.getConfig().getBoolean("donate.enabled", true)) {
            return "";
        }

        String defaultPrefix = plugin.getConfig().getString("donate.default_prefix", "");
        if (defaultPrefix == null) {
            defaultPrefix = "";
        }

        LuckPermsHook hook = plugin.getLuckPermsHook();
        if (hook == null) {
            return ChatColor.translateAlternateColorCodes('&', defaultPrefix);
        }

        String prefix = hook.getPrefix(player);
        if (prefix == null || prefix.trim().isEmpty()) {
            return ChatColor.translateAlternateColorCodes('&', defaultPrefix);
        }

        return ChatColor.translateAlternateColorCodes('&', prefix);
    }
}
