# GraveRP

Плагин для Spigot/Paper 1.16.5. Отправляет игроку ресурспак при входе на сервер
и отслеживает, принял он его или отклонил. Через PlaceholderAPI можно выводить
разные символы/текст в зависимости от статуса ресурспака:

- `has_pack` — используется, если игрок ПРИНЯЛ ресурспак (кастомные глифы шрифта).
- `no_pack` — используется, если игрок ОТКЛОНИЛ ресурспак или произошла ошибка загрузки
  (обычный текст, указанный в конфиге).

## Сборка

Требуется установленный Maven и Java 8+.

```bash
mvn clean package
```

Готовый файл `GraveRP.jar` появится в папке `target/`.

> Зависимости `spigot-api` и `placeholderapi` подгружаются автоматически из
> публичных репозиториев, указанных в `pom.xml`. Для сборки нужен доступ в интернет.

## Ссылки на ресурспак (Dropbox / Google Drive / GitHub)

Плагин умеет сам превращать "человеческие" ссылки в прямые ссылки на скачивание
(при `auto_convert_links: true` в конфиге):

| Сервис | Пример ссылки в конфиге | Что получится |
|---|---|---|
| Dropbox | `https://www.dropbox.com/s/xxxx/pack.zip?dl=0` | ссылка на `dl.dropboxusercontent.com` с `dl=1` |
| Google Drive | `https://drive.google.com/file/d/FILE_ID/view?usp=sharing` | `https://drive.google.com/uc?export=download&id=FILE_ID` |
| GitHub | `https://github.com/user/repo/blob/main/pack.zip` | `https://raw.githubusercontent.com/user/repo/main/pack.zip` |

Ссылки на GitHub Releases (`.../releases/download/...`) и уже прямые ссылки не трогаются.

> Обратите внимание: у Google Drive есть ограничение на файлы больше ~100 МБ
> (появляется страница с предупреждением антивируса вместо файла). Для больших
> ресурспаков лучше использовать свой хостинг, GitHub Releases или Dropbox.

## Плейсхолдер доната (LuckPerms)

Если на сервере установлен **LuckPerms**, плагин может подставлять вместо
обычного символа ресурспака префикс игрока (например, донатный ранг):

```
%graverp_donate%
```

- Если у игрока есть префикс в LuckPerms — выводится он.
- Если префикса нет, LuckPerms не установлен, либо плейсхолдер отключен
  (`donate.enabled: false`) — выводится `donate.default_prefix` из конфига.

LuckPerms указан как `softdepend` — плагин прекрасно работает и без него,
просто плейсхолдер доната будет возвращать значение по умолчанию.

## Сборка на GitHub Actions

В репозитории есть `.github/workflows/build.yml`. При каждом push/pull request
в ветку `main`/`master` GitHub автоматически соберёт плагин через Maven и
прикрепит `GraveRP.jar` как artifact к запуску workflow (вкладка **Actions**).

Если запушить тег вида `v1.0.0`, дополнительно создастся GitHub Release с
готовым `GraveRP.jar` во вложении. Запустить сборку вручную можно через
**Actions → Build → Run workflow** (`workflow_dispatch`).

### Автораспаковка архивов

Перед сборкой workflow ищет в репозитории все `.zip` файлы (например, архив с
ресурспаком) и распаковывает каждый в свою папку внутри `extracted/`.
Результат прикладывается к запуску как отдельный artifact **extracted-archives**
(вкладка Actions → выбранный run → Artifacts). Если архивов нет — шаг просто
пропускается, на сборку плагина это не влияет.

При ручном запуске (`workflow_dispatch`) можно указать `archives_path` —
папку, в которой искать архивы (по умолчанию — весь репозиторий).

## Установка

1. Положите `GraveRP.jar` и `PlaceholderAPI.jar` в папку `plugins/`.
2. Перезапустите сервер — создастся `plugins/GraveRP/config.yml`.
3. Укажите `resource_pack_url` (и при необходимости `resource_pack_hash`) в конфиге.
4. Настройте секции `placeholders` под свои нужды.
5. Используйте плейсхолдеры вида `%graverp_hrp%`, `%graverp_scoreboard_1%` и т.д.
   в скорбордах, чате, меню — где поддерживается PlaceholderAPI.

## Команды

- `/graverp` — краткая справка.
- `/graverp reload` — перезагрузить config.yml (право `graverp.admin`).
- `/graverp status [ник]` — посмотреть статус ресурспака игрока (право `graverp.admin`).

## Права

- `graverp.admin` — доступ к командам администрирования (по умолчанию: op).
